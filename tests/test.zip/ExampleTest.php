<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class ExampleTest extends TestCase
{
    use DatabaseMigrations;

    protected $URL = '/project';

    /**
     * A basic functional test example.
     *
     * @return void
     */
    public function testBasicExample()
    {
        $this->user = App\User::where('name', '=', 'admin')->firstOrFail();
    }

    public function testViewsWithSession()
    {
        $project = $this->user->projects()->where('name', '=', 'test')->firstOrFail();

        $this->actingAs($this->user)
            ->withSession('foo' => 'baz')
            ->visit($URL . '/create')
            ->assertResponseOk();

        $this->actingAs($this->user)
            ->withSession('foo' => 'baz')
            ->visit($URL)
            ->assertResponseOk()
            ->assertViewHas('projects', $this->user->projects()->all());

        $this->actingAs($this->user)
            ->withSession('foo' => 'baz')
            ->visit($URL . '/test')
            ->assertResponseOk()
            ->assertViewHas('project', $project);

        $this->actingAs($this->user)
            ->withSession('foo' => 'baz')
            ->visit($URL . '/test/edit')
            ->assertResponseOk()
            ->assertViewHas('project', $project);
    }

    public function testViewsNoSession()
    {
        $this->visit($URL . '/create')
            ->assertRedirectedTo('/home');

        $this->visit($URL)
            ->assertRedirectedTo('/home');

        $this->visit($URL . '/test')
            ->assertResponseOk()
            ->assertViewHas(
                'project', App\Project::where('name', '=', str_slug('test', ' ')));

        $this->visit($URL . '/test/edit')
            ->assertRedirectedTo('/home');
    }
}
